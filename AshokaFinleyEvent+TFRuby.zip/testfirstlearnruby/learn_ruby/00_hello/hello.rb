def hello
  return "Hello!"
end

def greet(name)
  return "Hello, #{name}!"
end
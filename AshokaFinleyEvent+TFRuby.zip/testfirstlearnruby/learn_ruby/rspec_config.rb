RSpec.configure do |c|
  c.fail_fast = true
  c.color = true
end
